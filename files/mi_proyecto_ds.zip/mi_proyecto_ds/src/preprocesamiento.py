# Funciones para cargar y preprocesar datos
import pandas as pd

def cargar_datos(ruta_archivo):
    return pd.read_csv(ruta_archivo)

# Otras funciones de preprocesamiento
